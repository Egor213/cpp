#define _GNU_SOURCE
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/wait.h>
#include <signal.h>
#include <errno.h>
#include <sys/types.h>
#include <unistd.h>


int main(int argc, char *argv[])
{
    int pid[3], ppid, status[3];                                 // инициализируем переменные для хранения pid и status процессов
    siginfo_t *infop;                                            // структура для записи освных данных
    char *names[] = {"task9_son1", "task9_son2", "task9_son3"};                    // имена исполняемых файлов
    printf("Parent pid = %d, ppid = %d\n", getpid(), getppid()); // выводим данные о процессе родителе
    for (int i = 0; i < 3; i++)                                  // в цикле создаем процессы потомки
        if ((pid[i] = fork()) == 0)
            execl(names[i], names[i], NULL);
    system("ps xf > file.txt"); // фиксируем состояние системы
    while (1)                   // запускаем цикл отслеживания состоянии процессов
    {
        int a = waitid(P_ALL, -1, infop, WEXITED | WSTOPPED | WCONTINUED); // с помощью функции waitid ожидаем реакции от любого процесса
        if (a == -1)                                                       // /проверяем, что процессов больше не осталось
        {
            printf("Все процессы завершены\n");
            break;
        }   
        printf("pid = %d, status = %d\n", infop->si_pid, infop->si_status); // выводим информацию о процессах
        switch (infop->si_code)
        {
        case CLD_EXITED:
            printf("Потомок успешно завершился с помощью exit или return\n");
            break;
        case CLD_KILLED:
            printf("Потомок завершил работу по сигналу\n");
            break;
        case CLD_STOPPED:
            printf("Потомок приостановлен по сигналу\n");
            break;
        case CLD_CONTINUED:
            printf("Потомок продолжил работу по сигналу SIGCONT\n");
            break;
        default:
            printf("Что-то странное вылезло\n");
            break;
        }
    }
}