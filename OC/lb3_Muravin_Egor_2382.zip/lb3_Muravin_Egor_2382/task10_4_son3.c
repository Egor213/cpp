#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sched.h>
#include <time.h>
#include <sys/wait.h>
#include <syslog.h>
#include <sys/time.h>
#include <fcntl.h>
#define N 2

void getPolicy(int pid)
{
    openlog("SON3_POLICY", LOG_PID, LOG_USER);
    switch (sched_getscheduler(pid))
    {
    case SCHED_FIFO:
        syslog(LOG_DEBUG, "SCHED_FIFO");
        break;
    case SCHED_RR:
        syslog(LOG_DEBUG, "SCHED_RR");
        break;
    case SCHED_OTHER:
        syslog(LOG_DEBUG, "SCHED_OTHER");
        break;
    case -1:
        syslog(LOG_DEBUG, "ОШИБКА");
        break;
    default:
        syslog(LOG_DEBUG, "НЕИЗВЕСТНО");
        ;
    }
    closelog();
}

void getPrior(struct sched_param *shdprm, int pid)
{
    openlog("SON3_PRIORITY", LOG_PID, LOG_USER);
    if (sched_getparam(pid, shdprm) == 0)
    {
        syslog(LOG_DEBUG, "Текущий приоритет текущего процесса: %d\n", shdprm->sched_priority);
    }
    closelog();
}

int main(int argc, char *argv[])
{
    cpu_set_t mask;
    CPU_ZERO(&mask);                                // Очищаем маску
    CPU_SET(0, &mask);                              // Устанавливаем CPU 0
    sched_setaffinity(0, sizeof(cpu_set_t), &mask); // устанавливаем одно ядро

    int pid, ppid;
    pid = getpid();
    ppid = getppid();
    int file = atoi(argv[1]); // считываем значение пришедшего дескриптора
    
    struct sched_param sched;
    sched.sched_priority = sched_get_priority_max(SCHED_OTHER); // устанавливаем приоритет
    if (sched_setscheduler(0, SCHED_OTHER, &sched) == -1) // устанавливаем политику планирования
                perror("SCHED_SETSCHEDULER_1");
    getPolicy(pid); // получаем политику процесса
    getPrior(&sched, pid); // получаем приоритет процесса

    int j = 0;
    for (int j = 0; j < 5; j++)// выполняем некотурую работу и записываем информацию в файл
    {
        char c = '3';
        write(file, &c, 1);
        for (int i = 0; i < 1 * 1e8; i++)
        {
        }
    }
    closelog();
    return 0;
}