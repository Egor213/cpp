#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/wait.h>

int main(int argc, char *argv[])
{
    int pid[3], ppid, status[4]; // инициализируем переменные для хранения pid и status процессов
    status[3] = 123;
    printf("Parent pid = %d, ppid = %d\n", getpid(), getppid()); // выводим данные о процессе родителе
    if ((pid[0] = fork()) == 0)                                  // создаем и конструем три процесса потомка
        execl("task9_son1", "task9_son1", (char *)NULL);
    if ((pid[1] = fork()) == 0)
        execl("task9_son2", "task9_son2", (char *)NULL);
    if ((pid[2] = fork()) == 0)
        execl("task9_son3", "task9_son3", (char *)NULL);
    for (int i = 0; i < 4; i++)
    {
        int j = wait(&status[i]);                                    // вызываем функцию wait для ожидания завершения процессов и записываем результат в status
        printf("wait was return = %d\nstatus = %d\n", j, status[i]); // выводим информацию о процесах потомках
    }
}