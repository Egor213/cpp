#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sched.h>
#include <time.h>
#include <sys/wait.h>
#include <syslog.h>
#include <sys/time.h>
#include <fcntl.h>
void getPolicy(int pid)
{
    openlog("FATHER_POLICY", LOG_PID, LOG_USER);
    switch (sched_getscheduler(pid))
    {
    case SCHED_FIFO:
        syslog(LOG_DEBUG, "SCHED_FIFO");
        break;
    case SCHED_RR:
        syslog(LOG_DEBUG, "SCHED_RR");
        break;
    case SCHED_OTHER:
        syslog(LOG_DEBUG, "SCHED_OTHER");
        break;
    case -1:
        syslog(LOG_DEBUG, "ОШИБКА");
        break;
    default:
        syslog(LOG_DEBUG, "НЕИЗВЕСТНО");
        ;
    }
    closelog();
}

void getPrior(struct sched_param *shdprm, int pid)
{
    openlog("FATHER_PRIORITY", LOG_PID, LOG_USER);
    if (sched_getparam(pid, shdprm) == 0)
    {
        syslog(LOG_DEBUG, "Текущий приоритет текущего процесса: %d\n", shdprm->sched_priority);
    }
    closelog();
}

int main()
{
    cpu_set_t mask;
    CPU_ZERO(&mask);                                // Очищаем маску
    CPU_SET(0, &mask);                              // Устанавливаем CPU 0
    sched_setaffinity(0, sizeof(cpu_set_t), &mask); // устанавливаем одно ядро

    int file = open("infile.txt", O_WRONLY);
    char str1[10];
    sprintf(str1, "%d", file);

    struct sched_param sched;

    openlog("task10.1_FATHER", LOG_PID, LOG_USER);

    

    int my_pid, my_ppid, pid[3];
    my_pid = getpid();
    my_ppid = getppid();


    if (sched_setscheduler(0, SCHED_RR, &sched) == -1) // устанавливаем политику планирования
                perror("SCHED_SETSCHEDULER_1");


    getPolicy(pid); // получаем политику процесса
    getPrior(&sched, pid); // получаем приоритет процесса
    for (int i = 0; i < 4; i++)
    {
        if ((pid[i] = fork()) == 0)
        {
            execl("son1", "son1", str1, NULL);
        }
    }

    for (int j = 0; j < 5; j++) // выполняем некотурую работу и записываем информацию в файл
    {
        char c = 'R';
        write(file, &c, 1);
        for (int i = 0; i < 1 * 1e7; i++)
        {
        }
    }

    system("ps xf > file.txt");
    closelog();
    for (int i = 0; i < 4; i++) // ожидаем завершения процессов
    {
        wait(NULL);
    }

    return 0;
}