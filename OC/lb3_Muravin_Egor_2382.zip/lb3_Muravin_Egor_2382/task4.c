#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sched.h>
#include <fcntl.h>

int n = 0;

void getPolicy(int pid)
{
    switch (sched_getscheduler(pid))
    {
    case SCHED_FIFO:
        printf("SCHED_FIFO\n");
        break;
    case SCHED_RR:
        printf("SCHED_RR\n");
        break;
    case SCHED_OTHER:
        printf("SCHED_OTHER\n");
        break;
    case -1:
        perror("SCHED_GETSCHEDULER");
        break;
    default:
        printf("Неизвестная политика планирования\n");
    }
}

int main()
{
    int pid;
    struct sched_param param;
    cpu_set_t mask;
    CPU_ZERO(&mask);   // Очищаем маску
    CPU_SET(0, &mask); // Устанавливаем CPU 0

    printf("Изначальный приоритет: %d\n", param.sched_priority); // получаем значение текущего приоритета
    printf("Изначальная политика: ");
    getPolicy(getpid());                                   // получаем текущую схему планирования
    sched_setaffinity(getpid(), sizeof(cpu_set_t), &mask); // устанавливаем одно ядро

    int fdrd = open("infile.txt", O_WRONLY);

    pid = fork(); // с помощью функции fork() порождаем дополнительный процесс

    if (pid == -1) // проверяем на корректность создания процесса
    {
        perror("fork"); // выводим сообщение об ошибке
        exit(1);        // выходим из программы
    }
    int status;
    if (pid == 0) // если процесс порожден корректно это процесс потомок
    {
        param.sched_priority = sched_get_priority_max(SCHED_FIFO);       // устанавливаем новое значение приоритета для потомка процесса
        sched_setscheduler(getpid(), SCHED_FIFO, &param);                // устанавливаем новое значение приоритета
        printf("Приоритет потомка после: %d\n", param.sched_priority); // получаем текущий приоритет
        printf("Политика потомка после: ");                            // получаем текущую схему планирования
        getPolicy(getpid());

        printf("new pid = %d, ppid =%d \n", getpid(), getppid()); // выводим pid процесса и его родителя
        char c = 'p';
        for (int i = 0; i < 10; i++)
        {
            write(fdrd, &c, 1);
            for (int j = 0; j < 2 * 1e9; j++)
            {
            }
        }
    }
    else // процесс родитель
    {
        param.sched_priority = sched_get_priority_max(SCHED_FIFO) - 1; // устанавливаем новое значение приоритета для потомка процесса
        sched_setscheduler(getpid(), SCHED_FIFO, &param);
        printf("Приоритет родителя после: %d\n", param.sched_priority);
        printf("Политика родителя после: "); // получаем текущую схему планирования
        getPolicy(getpid());

        printf("parent pid = %d, ppid =%d \n", getpid(), getppid()); // выводим pid процесса и его родителя
        char c = 'R';
        for (int i = 0; i < 10; i++)
        {
            write(fdrd, &c, 1);
            for (int j = 0; j < 2 * 1e9; j++)
            {
            }
        }
    }
    printf("Завершение процесса pid = %d\n", getpid());
    exit(0);
}