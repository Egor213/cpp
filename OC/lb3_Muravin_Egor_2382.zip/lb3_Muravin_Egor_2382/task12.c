#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sched.h>
#include <time.h>
#include <sys/wait.h>
#include <syslog.h>
#include <sys/time.h>
#include <sys/mman.h>

void getPolicy(int pid)
{
    switch (sched_getscheduler(pid))
    {
    case SCHED_FIFO:
        printf("SCHED_FIFO\n");
        break;
    case SCHED_RR:
        printf("SCHED_RR\n");
        break;
    case SCHED_OTHER:
        printf("SCHED_OTHER\n");
        break;
    case -1:
        printf("ОШИБКА");
        break;
    default:
        printf("НЕИЗВЕСТНО");
        ;
    }
}

void getPrior(struct sched_param *shdprm, int pid)
{
    if (sched_getparam(pid, shdprm) == 0)
    {
        printf("Текущий приоритет текущего процесса: %d\n", shdprm->sched_priority);
    }
}

int main()
{
    int pid, ppid;
    struct sched_param sched;
    sched.sched_priority = 50;
    sched_setscheduler(0, SCHED_RR, &sched);
    printf("FATHER pid = %d, ppid = %d\n", getpid(), getppid());
    printf("FATHER policy: ");
    getPolicy(getpid());
    getPrior(&sched, getpid());
    if (fork() == 0)
    {
        execl("task12_son2", "task12_son2", NULL);
        
    }
    system("ps -o uid,gid,ruid,pid,ppid,pgid,tty,vsz,stat,command > file.txt");
    for(int i = 0; i < 2 * 1e9; i++) {}
    printf("процесс pid = %d завершен\n", getpid());

    return 0;
}