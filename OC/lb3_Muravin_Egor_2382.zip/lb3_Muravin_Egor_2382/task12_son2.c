#define _GNU_SOURCE
#include <sys/mman.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sched.h>
#include <time.h>
#include <sys/wait.h>
#include <syslog.h>
#include <sys/time.h>
#include <sys/mman.h>
void getPolicy(int pid)
{
    switch (sched_getscheduler(pid))
    {
    case SCHED_FIFO:
        printf("SCHED_FIFO\n");
        break;
    case SCHED_RR:
        printf("SCHED_RR\n");
        break;
    case SCHED_OTHER:
        printf("SCHED_OTHER\n");
        break;
    case -1:
        printf("ОШИБКА");
        break;
    default:
        printf("НЕИЗВЕСТНО");
        ;
    }
}

void getPrior(struct sched_param *shdprm, int pid)
{
    if (sched_getparam(pid, shdprm) == 0)
    {
        printf("Текущий приоритет текущего процесса: %d\n", shdprm->sched_priority);
    }
}
int main(int argc, char *argv[])
{
    int pid, ppid, buf;
    struct sched_param sched;
    pid = getpid();
    ppid = getppid();
    printf("son params: pid=%i ppid=%i\nSON policy: ", pid, ppid);
    getPolicy(getpid());
    getPrior(&sched, getpid());
    sleep(10);
    return 0;
}