#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sched.h>
#include <time.h>
#include <sys/wait.h>
#include <syslog.h>
#include <sys/time.h>
int main()
{
    printf("SON PARAMS: pid=%i ppid=%i\n", getpid(), getppid());
    return 0;
}