#include <signal.h>
#include <pthread.h>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <sched.h>

pthread_t t1, t2, t3;

void *thread1()
{
    printf("Thread_1 is started with id = %ld, pid = %d\n", syscall(SYS_gettid), getpid()); //выводим информацию о потоке
    int i = 0;
    for (int j = 0; j < 3; j++)
    {
        printf("Интервал для 1 нити номер %d\n", ++i);// поток совершает некоторую работу
        sleep(5);
    }
    pthread_exit(NULL);
}

void *thread2()
{
    printf("Thread_2 is started with id = %ld, pid = %d\n", syscall(SYS_gettid), getpid()); //выводим информацию о потоке
    int i = 0;
    for (int j = 0 ; j < 15; j++)
    {
        printf("Интервал для 2 нити номер %d\n", ++i);// поток совершает некоторую работу
        sleep(1);
    }
    pthread_exit(NULL);
}

void *thread3()
{
    printf("Thread_3 is started with id = %ld, pid = %d\n", syscall(SYS_gettid), getpid()); //выводим информацию о потоке
    int i = 0; 
    for (int j = 0 ; j < 5; j++)
    {
        printf("Интервал для 3 нити номер %d\n", ++i); // поток совершает некоторую работу
        sleep(3);
    }
    pthread_exit(NULL);
}

int main()
{
    pthread_create(&t1, NULL, thread1, NULL); // создаем три новых потока
    pthread_create(&t2, NULL, thread2, NULL);
    pthread_create(&t3, NULL, thread3, NULL);
    pthread_join(t1, NULL); // ожидаем их завершения
    pthread_join(t2, NULL);
    pthread_join(t3, NULL);
    return 0;
}