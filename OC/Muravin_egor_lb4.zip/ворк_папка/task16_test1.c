#include <stdio.h>
#include <sys/time.h>
#include <sys/resource.h>
void main()
{
    int pr, pid, i;
    pid = getpid();

    setpriority(PRIO_PROCESS, pid, i); //пробуем установить новый приоритет процесса
    pr = getpriority(PRIO_PROCESS, pid);
    printf("Prog1 текущий приоритет: %d\n", pr);
}