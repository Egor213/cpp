#include <stdio.h>
#include <unistd.h>






int main()
{

    sleep(60);
    printf("Первая программа завершилась\n");
    return 0;
}