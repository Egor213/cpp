#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sched.h>
#include <time.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <syslog.h>
#include <sys/time.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <string.h>
#include <signal.h>

static void handler1(int sig)
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    syslog(LOG_INFO, "SIGUSR1 пришел в %ld сек. %ld млсек.", tv.tv_sec, tv.tv_usec); //получаем в syslog информацию о времени принятия сигнала
    signal(SIGUSR1, SIG_DFL);
    system("ps -sf > file.txt");// фиксируем состояние системы
    exit(0);
}
static void handler2(int sig)
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    syslog(LOG_INFO, "SIGUSR2 пришел в %ld сек. %ld млсек.", tv.tv_sec, tv.tv_usec); //получаем в syslog информацию о времени принятия сигнала
    signal(SIGUSR2, SIG_DFL);
    system("ps -sf > file2.txt"); // фиксируем состояние системы
    exit(0);
}

int main()
{
    openlog("my_program", LOG_PID|LOG_CONS, LOG_USER);
    int pids[2];

    signal(SIGUSR1, handler1); // устанавливаем новые диспозиции для сигналов
    signal(SIGUSR2, handler2);
    if ((pids[0] = fork()) == 0) // создаем два процесса 
    {
        sleep(30); // процесс спит
    }
    if ((pids[1] = fork()) == 0)
    {
        for(int i = 0; i < 10 * 1e9; i++) // процесс производит вычисления
        {}
    } 
    struct timeval tv;
    gettimeofday(&tv, NULL);
    syslog(LOG_INFO, "SIGUSR1 отправлен в %ld сек. %ld млсек.", tv.tv_sec, tv.tv_usec); //получаем в syslog информацию о времени отправки сигнала
    kill(pids[0], SIGUSR1); //посылаем сигнал потомку
    gettimeofday(&tv, NULL);
    syslog(LOG_INFO, "SIGUSR2 отправлен в %ld сек. %ld млсек.", tv.tv_sec, tv.tv_usec);//получаем в syslog информацию о времени отправки сигнала
    kill(pids[1], SIGUSR2); // посылаем сигнал потомку
    wait(NULL); // ждем завершения процессов
    wait(NULL);
    closelog();
    return 0;
}