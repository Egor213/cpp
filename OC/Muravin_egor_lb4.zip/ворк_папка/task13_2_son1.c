#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sched.h>
#include <time.h>
#include <sys/wait.h>
#include <syslog.h>
#include <sys/time.h>
#include <fcntl.h>
#include <sys/mman.h>
int main(int argc, char *argv[])
{
    int fdwr = atoi(argv[1]);
    int pid, ppid;
    pid = getpid();
    ppid = getppid();
    write(fdwr, "son1_start\n", 11); // записываем информацию о процессе в файл
    printf("SON_1 PARAMS: pid=%i ppid=%i\nFather creates and waits \n", pid, ppid); //выводим информацию о процессе
    sleep(3);
    write(fdwr, "son1_finish\n", 12); // записываем информацию о процессе в файл
    return 0;
}