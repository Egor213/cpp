#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sched.h>
#include <time.h>
#include <sys/wait.h>
#include <syslog.h>
#include <sys/time.h>

int main()
{
    int pid, ppid;
    pid = getpid();
    ppid = getppid();
    printf("SON_1 PARAMS: pid=%i ppid=%i\nFather creates and waits \n", pid, ppid); // выводим информацию о потомке
    sleep(3);
    return 0;
}