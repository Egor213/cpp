#include <stdio.h>


int main()
{

    for (int i = 0; i < 1 * 1e100; i++)
    {
        if ((i % 1000000000)== 0)
        {
            printf("Точка вывода сообщения\n");
        }
    }


    return 0;
}