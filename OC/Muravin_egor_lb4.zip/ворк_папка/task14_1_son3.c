#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sched.h>
#include <time.h>
#include <sys/wait.h>
#include <syslog.h>
#include <sys/time.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <string.h>
#include <signal.h>

static void sigHandler(int sig)
{
    printf("Catched signal SIGINT\n");
    printf("Parent = %d\n", getppid()); 
    signal(sig, SIG_DFL); // востанавливаем старую диспозицию
}

int main()
{
    printf("SON3 pid=%i, ppid=%i\n", getpid(), getppid());
    signal(SIGINT, sigHandler); //устанавливаем новую диспозицию сигнала
    for (;;){ pause();} // ждем сигнал
    printf("SON3 WAS FINISHED\n");
    return 0;
}