#!/bin/bash


sudo ./check