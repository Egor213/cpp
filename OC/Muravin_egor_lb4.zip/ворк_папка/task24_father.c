#include <signal.h>
#include <pthread.h>
#include <stdio.h>
#include <sys/types.h>
#include <linux/unistd.h>
#include <sys/syscall.h>
#include <syslog.h>

pthread_t t1, t2;
void hnd(int sig)
{
    
    switch (sig) // выбираем необходимы сценарий для отработки полученного сигнала
    {
    case SIGUSR1:
        printf("Catched SIGUSR1 %d\n", sig);
        sleep(1);
        signal(sig, hnd);
        break;
    
    case SIGUSR2:
        printf("Catched SIGUSR2 %d\n", sig);
        sleep(1);
        signal(sig, hnd);
        break;
    }
   
    if (sig == SIGRTMIN)
    {
        printf("Catched SIGRTMIN %d\n", sig);
        sleep(1);
        signal(sig, hnd);
        return;
    }

    if (sig == SIGRTMIN + 1)
    {
        printf("Catched SIGRTMIN+1 %d\n", sig);
        sleep(1);
        signal(sig, hnd);
        return;
    }
    
    if (sig == SIGRTMIN + 2)
    {
        printf("Catched SIGRTMIN+2 %d\n", sig);
        sleep(1);
        signal(sig, hnd);
        return;
    }
    
}
void *thread1()
{
    int i, count = 0;
    int tid, pid;
    tid = syscall(SYS_gettid);
    pid = getpid();
    printf("Thread_1 with thread id = %d and pid = %d is started\n", tid, pid); // выводим информацию о потоке
    int n = 1; 
    for (i = 0; i < n; i++)
    {
        count += 1;
        printf("Thread_1: step %d \n", count);
        sleep(5);
        // отправка обычных сигналов из первой нити во вторую
        //тестируем "слопывание" обычных сигналов
        pthread_kill(t2, SIGUSR2);
        pthread_kill(t2, SIGUSR1);
        pthread_kill(t2, SIGUSR1);
        pthread_kill(t2, SIGUSR1);
        pthread_kill(t2, SIGUSR1);
        //теперь проверим сигналы реального времени
        pthread_kill(t2, SIGRTMIN);
        pthread_kill(t2, SIGRTMIN);
        pthread_kill(t2, SIGRTMIN);
        //протестируем создание очереди по приоритетам
        pthread_kill(t2, SIGRTMIN + 1); // отправка сигналов реального времени
        pthread_kill(t2, SIGRTMIN + 1);
        pthread_kill(t2, SIGRTMIN);
        pthread_kill(t2, SIGRTMIN + 2);
        pthread_kill(t2, SIGRTMIN);
    }
}
void *thread2()
{
    int i, count = 0;
    int tid, pid;
    tid = syscall(SYS_gettid);
    pid = getpid();
    printf("Thread_2 with thread id = %d and pid = %d is started\n", tid, pid); // выводим информацию о потоке
    int m = 10;
    for (i = 0; i < m; i++) // имитируем работу потока
    {
        count += 1;
        sleep(1);
        printf("Thread_2: step %d\n", count);
    }
}
void main()
{
    signal(SIGUSR1, hnd); // устанавливаем для сигналов обработчики сигналов
    signal(SIGUSR2, hnd);
    signal(SIGRTMIN, hnd);
    signal(SIGRTMIN + 1, hnd);
    signal(SIGRTMIN + 2, hnd);
    pthread_create(&t1, NULL, thread1, NULL); // создаем два потока
    pthread_create(&t2, NULL, thread2, NULL);
    pthread_join(t1, NULL); // ожидаем их завершения
    pthread_join(t2, NULL);
}