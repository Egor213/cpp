#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sched.h>
#include <time.h>
#include <sys/wait.h>
#include <syslog.h>
#include <sys/time.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <string.h>
#include <signal.h>


int main()
{
    int pids[3], status[3];
    siginfo_t *infop;
    printf("FATHER pid=%i, ppid=%i\n", getpid(), getppid()); // выводим информацию о родительском процессе
    if ((pids[0] = fork()) == 0) // создаем и конструируем трех потомков основного процесса
        execl("son1", "son1", NULL);
    if ((pids[1] = fork()) == 0)
        execl("son2", "son2", NULL);
    if ((pids[2] = fork()) == 0)
        execl("son3", "son3", NULL);
    system("echo \"\nkill_1\n\" > file.txt"); //записываем в файл информацию о системе
    system("ps -sf >> file.txt");
    kill(pids[0], SIGUSR1);// посылаем сигнал потомку
    system("echo \"\nkill_2\n\" >> file.txt");//записываем в файл информацию о системе
    system("ps -sf >> file.txt");
    kill(pids[1], SIGUSR2);// посылаем сигнал потомку
    system("echo \"\nkill_3\n\" >> file.txt");//записываем в файл информацию о системе
    system("ps -sf >> file.txt");
    kill(pids[2], SIGINT);// посылаем сигнал потомку
    system("echo \"\nkill_finish\n\" >> file.txt");
    system("ps -sf >> file.txt");//записываем в файл информацию о системе
    printf("FATHER WAS FINISHED\n");
    return 0;
}