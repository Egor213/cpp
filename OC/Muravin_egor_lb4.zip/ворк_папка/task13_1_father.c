#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sched.h>
#include <time.h>
#include <sys/wait.h>
#include <syslog.h>
#include <sys/time.h>



int main()
{

    int pid, sid, ppid, pids[3];
    char* names[] = {"task13_1_son1", "task13_1_son2", "task13_1_son3"}; // массив имен файлов для порождения процессов
    pid = getpid(); // получаем pid процесса
    ppid = getppid(); // получаем pid родителя
    sid = getsid(pid); // получаем sid процесса
    int status;
    printf("FATHER PARAMS: pid=%i ppid=%i, sid=%i\n", pid, ppid, sid);
    char command[50];
    sprintf(command, "ps xjf | grep \"STAT\\|%d\" > %s", sid, "file.txt");  // записываем команду в массив command
    for (int i = 0; i < 3; i++) // в цикле создаем трех потомков
    {
        if ((pids[i] = fork()) == 0) // конструируем потомков
        {
            execl(names[i], names[i], NULL);
        }
    }
    system(command); // вызываем команду из переменной command, которая записываешь состояния процессов в файл file.txt
    waitpid(pids[0], &status, WUNTRACED); //  ожидаем выполнение первого процесса 
    return 0;
}