#include <stdio.h>
#include <unistd.h>

int main()
{

    sleep(60);
    printf("Вторая программа завершилась\n");

    return 0;
}