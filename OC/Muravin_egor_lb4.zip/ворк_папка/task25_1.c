#define _GNU_SOURCE
#include <signal.h>
#include <pthread.h>
#include <stdio.h>
#include <sys/types.h>
#include <linux/unistd.h>
#include <sys/syscall.h>
#include <sched.h>
#include <syslog.h>
#include <stdio.h>
#include <sched.h>
#include <sys/mman.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

pthread_t t1, t2;
int fdrd;
void *thread1()
{
    int i, count = 0;
    int tid, pid;
    char c = '1';
    tid = syscall(SYS_gettid);
    pid = getpid();
    printf("Thread_1 with thread id = %d and pid = %d is started\n", tid, pid); // выводим информацию о потоке
    for (i = 0; i < 100; i++)
    {
        write(fdrd, &c, 1); // записываем в файл информацию о работе потока
    }
}
void *thread2()
{
    int i, count = 0;
    int tid, pid;
    char c = '2';
    tid = syscall(SYS_gettid);
    pid = getpid();
    printf("Thread_2 with thread id = %d and pid = %d is started\n", tid, pid); // выводим информацию о потоке
    for (i = 0; i < 100; i++)
    {
        write(fdrd, &c, 1); // записываем в файл информацию о работе потока
    }
}

void getPolicy(int policy)
{
    switch (policy) // выводим полученную политику
    {
    case SCHED_FIFO:
        printf("policy SCHED_FIFO\n");
        break;
    case SCHED_RR:
        printf("policy SCHED_RR\n");
        break;
    case SCHED_OTHER:
        printf("policy SCHED_OTHER\n");
        break;
    case -1:
        perror("policy SCHED_GETSCHEDULER");
        break;
    default:
        printf("policy Неизвестная политика планирования\n");
    }
}

void main()
{
     /* cpu_set_t mask;
     CPU_ZERO(&mask);   // Очищаем маску
     CPU_SET(0, &mask); // Устанавливаем CPU 0
     sched_setaffinity(getpid(), sizeof(cpu_set_t), &mask); // устанавливаем одно ядро */
    fdrd = open("file.txt", O_RDWR);
    int policy;
    struct sched_param param;                      // структура, используемая для получения и установки политики планирования процессов
    pthread_attr_t attr_1, attr_2;                 // структура, используется для создания и управления атрибутами потока
    pthread_attr_init(&attr_1);                    // инициализация данной структуры
    pthread_attr_init(&attr_2);                    // инициализация данной структуры
    pthread_attr_getschedparam(&attr_1, &param);   // получаем параметры планирования
    pthread_attr_getschedpolicy(&attr_1, &policy); // получаем политику планирования
    printf("Thread_1's priority = %d\n", param.sched_priority); // выводим информацию о приоритете потока
    getPolicy(policy); // выводим политику потока
    pthread_attr_getschedparam(&attr_2, &param); // получаем характеристики планирования
    pthread_attr_getschedpolicy(&attr_2, &policy);
    printf("Thread_2's priority = %d\n", param.sched_priority);// выводим информацию о приоритете потока
    getPolicy(policy);
    pthread_create(&t1, &attr_1, thread1, NULL); // создаем поток
    pthread_create(&t2, &attr_2, thread2, NULL);
    pthread_join(t1, NULL); // ожидаем поток
    pthread_join(t2, NULL);
    pthread_attr_destroy(&attr_1); // разрушаем структуру attr
    pthread_attr_destroy(&attr_2);
    closelog();
}