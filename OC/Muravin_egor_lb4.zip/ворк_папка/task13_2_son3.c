#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sched.h>
#include <time.h>
#include <sys/wait.h>
#include <syslog.h>
#include <sys/time.h>



int main(int argc, char *argv[])
{
    int pid, ppid;
    pid = getpid();
    ppid = getppid();
    int fdwr = atoi(argv[1]);
    write(fdwr, "son3_start\n", (11)); // записываем информацию о процессе в файл
    printf("SON_3 PARAMS: pid=%i ppid=%i\nson3 terminated – ZOMBIE\n", pid, ppid); // выводим информацию о процессе
    ppid = getppid();
    printf("SON_3 PARAMS: pid=%i ppid=%i\n", pid, ppid);
    write(fdwr, "son3_finish\n", (12)); // записываем информацию о процессе в файл
    return 0;
}