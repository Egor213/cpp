#include <signal.h>
#include <pthread.h>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <sched.h>

pthread_t t1, t2;

void *thread1()
{
    printf("Thread_1 is started with id = %ld, pid = %d\n", syscall(SYS_gettid), getpid());// выводим информацию о потоке
    int i = 0;
    for (int j = 0; j < 4; j++)
    {
        printf("Интервал для 1 нити номер %d\n", ++i); // поток совершает некоторую работу
        sleep(5);
        if (j == 0)
            pthread_kill(t2, SIGUSR1); // на первом цикле, т.е. после 5 секунд после начала работы, первый поток посылает сигнал второму потоку
    }
}

void *thread2()
{
    printf("Thread_2 is started with id = %ld, pid = %d\n", syscall(SYS_gettid), getpid()); // выводим информацию о потоке
    int i = 0;
    for (int j = 0 ; j < 15; j++)
    {
        printf("Интервал для 2 нити номер %d\n", ++i); //  поток совершает некоторую работу
        sleep(1);
    }
}

int main()
{
    pthread_create(&t1, NULL, thread1, NULL); // создаем два потока
    pthread_create(&t2, NULL, thread2, NULL); 
    pthread_join(t1, NULL); // ожидаем их завершения
    pthread_join(t2, NULL);
    return 0;
}