#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sched.h>
#include <time.h>
#include <sys/wait.h>
#include <syslog.h>
#include <sys/time.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <string.h>
#include <signal.h>

int main()
{
    printf("SON1 pid=%i, ppid=%i\n", getpid(), getppid());
    signal(SIGUSR1, SIG_DFL); // устанавливаем реакцию по умолчанию
    for (;;) // ждем сигнал
    {
        pause();
    }
    printf("SON1 WAS FINISHED\n");
    return 0;
}