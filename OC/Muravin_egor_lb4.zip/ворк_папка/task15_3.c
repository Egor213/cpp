#include <stdio.h>
#include <unistd.h>


int main()
{

    sleep(60);
    printf("Третья программа завершилась\n");

    return 0;
}