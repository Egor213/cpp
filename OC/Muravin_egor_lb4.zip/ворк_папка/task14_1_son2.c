#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sched.h>
#include <time.h>
#include <sys/wait.h>
#include <syslog.h>
#include <sys/time.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <string.h>
#include <signal.h>


int main()
{
    printf("SON2 pid=%i, ppid=%i\n", getpid(), getppid());
    signal(SIGUSR2, SIG_IGN); // устанавливаем игнорирование сигнала
    for (;;) { pause(); } // ждем сигнал
    printf("SON2 WAS FINISHED\n");
    return 0;
}