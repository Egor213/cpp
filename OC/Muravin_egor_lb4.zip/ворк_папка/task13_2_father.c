#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sched.h>
#include <time.h>
#include <sys/wait.h>
#include <syslog.h>
#include <sys/time.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <string.h>


void itoa(char *buf, int value)
{
    sprintf(buf, "%d", value);
}

int main()
{
    char str1[50];

    int fdwr;
    if ((fdwr = creat("outfile.txt", 0666)) == -1) // создаем файл для записи
        perror("Creating file");

    itoa(str1, fdwr); // записываем в массив дескриптор файла


    int pid, sid, ppid, pids[3];
    char *names[] = {"task13_2_son1", "task13_2_son2", "task13_2_son3"}; // массив имен файлов для порождения процессов
    pid = getpid();
    ppid = getppid();
    sid = getsid(pid);
    int status;
    printf("FATHER PARAMS: pid=%i ppid=%i, sid=%i\n", pid, ppid, sid); // выводим информацию о процессе
    write(fdwr, "father_start\n", 13); // записываем в файл информацию
    char command[50];
    sprintf(command, "ps xjf | grep \"STAT\\|%d\" > %s", sid, "file.txt"); //сохраняем в массив команду
    for (int i = 0; i < 3; i++) // в цикле создаем трех потомков
    {
        if ((pids[i] = fork()) == 0)
        {
            execl(names[i], names[i], str1, NULL); //коснтруируем процесс
        }
    }
    system(command);                      // вызываем команду из переменной command, которая записываешь состояния процессов в файл file.txt
    waitpid(pids[0], &status, WUNTRACED); //  ожидаем выполнение первого процесса
    write(fdwr, "father_finish\n", 14);
    return 0;
}