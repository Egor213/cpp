#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sched.h>
#include <time.h>
#include <sys/wait.h>
#include <syslog.h>
#include <sys/time.h>

int main(int argc, char *argv[])
{
    int pid, ppid;
    pid = getpid();
    ppid = getppid();
    int fdwr = atoi(argv[1]);
    char command[50];
    write(fdwr, "son2_start\n", (11)); // записываем информацию о процессе в файл
    sprintf(command, "ps xjf | grep son2 >> %s", "file.txt"); // записываем команду в массив
    printf("SON_2 PARAMS: pid=%i ppid=%i\nFather finished before son termination without waiting for it \n", pid, ppid); // выводим информацию о процессе
    sleep(20);
    ppid = getppid();
    printf("SON_2 PARAMS ARE CHANGED: pid=%i ppid=%i\n", pid, ppid);
    system(command); // вызываем записанную команду
    write(fdwr, "son2_finish\n", (12)); // записываем информацию о процессе в файл
    return 0;
}