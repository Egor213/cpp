#include <stdio.h>
#include <signal.h>
#include <stdlib.h>

void handlerINT()
{
    puts("^C - signal received"); // информируем о поимке сигнала
    signal(SIGINT, SIG_DFL); // восстановление диспозиции по умолчанию
}

void handlerTSTP()
{
    static int z = 0;
    puts("^Z - signal received"); // информируем о поимке сигнала
    z++;
    if (z == 5) // мы можем ловить сигнал до 5 раз
        signal(SIGTSTP, SIG_DFL); // восстановление диспозиции по умолчанию
}



int main()
{
    int pid, ppid;
    pid = getpid();
    ppid = getppid();
    printf("Current pid = %d and ppid = %d\n", pid, ppid);
    signal(SIGINT, handlerINT); // устанавливаем написанные обработчики для сигналов
    signal(SIGTSTP, handlerTSTP);
    while (1) // ожидаем сигналов от пользователя
        ;
    return 0;
}