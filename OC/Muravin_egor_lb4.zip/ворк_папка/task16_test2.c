#include <stdio.h>
#include <sys/time.h>
#include <sys/resource.h>
void main()
{
    int pr, pid, i;
    pid = getpid();
    pr = getpriority(PRIO_PROCESS, pid); // получаем приоритет процесса
    printf("Prog2 текущий приоритет: %d\n", pr);
}