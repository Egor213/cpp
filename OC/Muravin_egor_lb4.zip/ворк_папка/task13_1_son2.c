#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sched.h>
#include <time.h>
#include <sys/wait.h>
#include <syslog.h>
#include <sys/time.h>

int main()
{
    int pid, ppid;
    pid = getpid();
    ppid = getppid();
    char command[50];
    sprintf(command, "ps xjf | grep son2 >> %s", "file.txt"); // записываем команду в массив 
    printf("SON_2 PARAMS: pid=%i ppid=%i\nFather finished before son termination without waiting for it \n", pid, ppid); // выводим информацию о потомке
    sleep(20);
    ppid = getppid();
    printf("SON_2 PARAMS ARE CHANGED: pid=%i ppid=%i\n", pid, ppid);
    system(command); // запускаем записанную команду
    return 0;
}