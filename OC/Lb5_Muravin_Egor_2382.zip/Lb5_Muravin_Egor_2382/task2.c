#define _GNU_SOURCE
#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>

void (*mysignal(int sig, void (*hnd)(int)))(int)
{
    struct sigaction act, oact;          // задаем структуры для установки обработчиков
    act.sa_handler = hnd;                // задаем обработчик
    sigemptyset(&act.sa_mask);           // очищаем маску
    sigaddset(&act.sa_mask, SIGUSR1);     // устанавливаем в маску блокируемые сигналы
    sigaddset(&act.sa_mask, SIGUSR2);
    sigaddset(&act.sa_mask, SIGRTMIN+1); // установим сигнал реального времени
    act.sa_flags = 0;                    // устанавливаем флаг
    if (sigaction(sig, &act, &oact) < 0) // устанавливаем новый обработчик и сохраняем старый
        return SIG_ERR;
    return oact.sa_handler; // возвращаем старый обработчик
}

void handlerINT(int sig) //обработчик сигналов
{
    printf("SIGINT обработчик начал работу\n");
    sleep(60);
    printf("SIGINT обработчик завершил работу\n");
}

void checkHandler(int sig) // обработчик сигналов для выводов в терминал
{
    if (sig == SIGUSR1)
    {
        puts("SIGUSR1 был пойман!");
        sleep(1);
        signal(SIGUSR1, checkHandler);
        return;
    }
    if (sig == SIGUSR2)
    {
        puts("SIGUSR2 был пойман!");
        sleep(1);
        signal(SIGUSR2, checkHandler);
        return;
    }
    if (sig == SIGRTMIN+1)
    {
        puts("SIGRTMIN+1 был пойман!");
        sleep(1);
        signal(SIGRTMIN+1, checkHandler);
        return;
    }
}


int main()
{
    signal(SIGUSR1, checkHandler); // устанавливаем информирующий обработчик
    signal(SIGUSR2, checkHandler);
    signal(SIGRTMIN+1, checkHandler);
    printf("pid = %d\n", getpid());
    mysignal(SIGINT, handlerINT); // устанавливаем обработчик сигналов
    for (;;)
        pause();
    return 0;
}