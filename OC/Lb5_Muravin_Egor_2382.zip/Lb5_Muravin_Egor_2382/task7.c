#define _GNU_SOURCE
#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>

void checkHandler(int signum, siginfo_t *info, void *context)
{
    sleep(1);
    printf("SIGMIN пришел с числом %d\n", info->si_value.sival_int);
}

int main()
{

    struct sigaction act;
    act.sa_sigaction = checkHandler;
    act.sa_flags = SA_SIGINFO; // Указываем использовать расширенную информацию о сигнале
    sigemptyset(&act.sa_mask); // Очищаем маску сигналов
    sigaction(SIGRTMIN, &act, NULL);
    int pids;
    if ((pids = fork()) == 0)   
    {
        execl("son", "son", NULL);
    }
    for (;;)
        pause();
    return 0;
}