#define _GNU_SOURCE
#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
struct sigaction old_act[3];
void handlerFirst(int signal)
{
    puts("SIGINT обработчик был запущен!");
    system("ps -sf >> file.txt");
    kill(getpid(), SIGINT);
    sleep(1);
    system("ps -sf >> file.txt");
    kill(getpid(), SIGUSR1);
    system("ps -sf >> file.txt");
    sleep(1);
    puts("SIGINT обработчик был завершен!");
   // sigaction(SIGINT, &old_act[0], NULL);
}

void handlerSecond(int signal)
{
    puts("SIGUSR1 обработчик был запущен!");
    kill(getpid(), SIGINT);
    sleep(1);
    kill(getpid(), SIGUSR1);
    sleep(1);
    puts("SIGUSR1 обработчик был завершен!");
   // sigaction(SIGUSR1, &old_act[1], NULL);
}

int main()
{
    struct sigaction act[3];
    act[0].sa_handler = handlerFirst; // устанавливаем обработчик сигналов
    sigemptyset(&act[0].sa_mask);  // очищаем маску
    sigaddset(&act[0].sa_mask, SIGUSR1); // устанавливаем блокирование сигнала
    act[0].sa_flags = 0;           // устанавливаем флаг
    sigaction(SIGINT, &act[0], &old_act[0]); // устанавливаем обработчик

    act[1].sa_handler = handlerSecond; // устанавливаем обработчик сигналов
    sigemptyset(&act[1].sa_mask);  // очищаем маску
    sigaddset(&act[1].sa_mask, SIGINT); // устанавливаем блокирование сигнала
    act[1].sa_flags = 0;           // устанавливаем флаг
    sigaction(SIGUSR1, &act[1], &old_act[1]); // устанавливаем обработчик

    for(;;)
        pause();

    
    return 0;
}