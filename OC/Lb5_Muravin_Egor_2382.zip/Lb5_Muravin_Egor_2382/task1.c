#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>


struct sigaction old_act[4]; // для хранения старых обработчиков

//Обработчики для сигналов
void handlerINT(int sig)
{
    printf("SIGINT был пойман!\n");
    sigaction(SIGINT, &old_act[0], NULL);
}

void handlerTERM(int sig)
{
    printf("SIGTERM был пойман!\n");
}

void handlerUSER1(int sig)
{
    printf("SIGUSR1 был пойман!\n");
    sleep(15);
    printf("SIGUSR1 обработчик завершил свою работу!\n");
    sigaction(SIGUSR1, &old_act[2], NULL);
}

void handlerUSER2(int sig)
{
    printf("SIGUSR2 был пойман!\n");
    sleep(15);
    printf("SIGUSR2 обработчик завершил свою работу!\n");
    sigaction(SIGUSR2, &old_act[3], NULL);
}

int main()
{
    struct sigaction new_act[4];

    printf("pid = %d\n", getpid());

    new_act[0].sa_handler = handlerINT; // устанавливаем обработчик сигналов
    sigemptyset(&new_act[0].sa_mask); // очищаем маску сигналов, это означает, что никакой сигнал не будет блокироваться во время выполнения обработчика
    new_act[0].sa_flags = 0; //устанавливаем нулевой флаг


    new_act[1].sa_handler = handlerTERM;// устанавливаем обработчик сигналов
    sigemptyset(&new_act[1].sa_mask); // очищаем маску сигналов, это означает, что никакой сигнал не будет блокироваться во время выполнения обработчика
    new_act[1].sa_flags = SA_ONESHOT; // устанавливаем флаг, чтобы обработчик автоматически восстановился после первого вызова обработчика


    new_act[2].sa_handler = handlerUSER1;// устанавливаем обработчик сигналов
    sigemptyset(&new_act[2].sa_mask); // очищаем маску сигналов, это означает, что никакой сигнал не будет блокироваться во время выполнения обработчика
    sigaddset(&new_act[2].sa_mask, SIGINT); // устанавливаем в маску SIGINT, теперь обработчик будет игнорировать данный сигнал
    new_act[2].sa_flags = 0;  //устанавливаем нулевой флаг

    new_act[3].sa_handler = handlerUSER2;// устанавливаем обработчик сигналов
    sigemptyset(&new_act[3].sa_mask); // очищаем маску сигналов, это означает, что никакой сигнал не будет блокироваться во время выполнения обработчика
    sigaddset(&new_act[3].sa_mask, SIGINT); // устанавливаем в маску SIGINT, теперь обработчик будет игнорировать данный сигнал
    new_act[3].sa_flags = SA_NODEFER; // устанавливаем флаг, чтобы разблокировать получание текущего сигнала

    //устанавливаем структуры для соответствующих сигналов
    sigaction(SIGINT, &new_act[0], &old_act[0]);
    sigaction(SIGTERM, &new_act[1], &old_act[1]);
    sigaction(SIGUSR1, &new_act[2], &old_act[2]);
    sigaction(SIGUSR2, &new_act[3], &old_act[3]);
    for (;;)
        pause();
    return 0;
}