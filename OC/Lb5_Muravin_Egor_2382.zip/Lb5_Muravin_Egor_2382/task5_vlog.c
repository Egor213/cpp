#define _GNU_SOURCE
#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>

void checkHandler(int signum, siginfo_t *info, void *context)
{
    sleep(1);
    printf("SIGMIN пришел с числом %d\n", info->si_value.sival_int);
    union sigval value;
    value.sival_int = 2;
    sigqueue(getpid(), SIGRTMIN, value); // Посылаем надежный сигнал SIGRTMIN с данными
    value.sival_int = 3;
    sigqueue(getpid(), SIGRTMIN, value); // Посылаем надежный сигнал SIGRTMIN с данными
}

int main()
{

    struct sigaction act;
    act.sa_sigaction = checkHandler;
    act.sa_flags = SA_SIGINFO; // Указываем использовать расширенную информацию о сигнале
    sigemptyset(&act.sa_mask); // Очищаем маску сигналов
    sigaction(SIGRTMIN, &act, NULL);
    int pids;
    if ((pids = fork()) == 0)
    {
        union sigval value;
        value.sival_int = 1;
        sigqueue(getppid(), SIGRTMIN, value); // Посылаем надежный сигнал SIGRTMIN с данными
    }
    sleep(5);
    for (;;)
        pause();
    return 0;
}