#define _GNU_SOURCE
#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>

void checkHandler(int sig) // обработчик сигналов для выводов в терминал
{
    if (sig == SIGUSR1)
    {
        puts("SIGUSR1 обработчик начал работу!");
        sleep(1);
        signal(SIGUSR1, checkHandler);
        return;
    }
    if (sig == SIGUSR2)
    {
        puts("SIGUSR2 обработчик начал работу!");
        sleep(1);
        signal(SIGUSR2, checkHandler);
        return;
    }
    if (sig == SIGBUS)
    {
        puts("SIGBUS обработчик начал работу!");
        sleep(1);
        signal(SIGBUS, checkHandler);
        return;
    }
    if (sig == SIGIO)
    {
        puts("SIGIO обработчик начал работу!");
        sleep(1);
        signal(SIGIO, checkHandler);
        return;
    }

    // Сигналы реального времени
    if (sig == SIGRTMIN)
    {
        puts("SIGRTMIN обработчик начал работу!");
        sleep(1);
        signal(SIGRTMIN, checkHandler);
        return;
    }

    if (sig == SIGRTMIN + 1)
    {
        puts("SIGRTMIN+1 обработчик начал работу!");
        sleep(1);
        signal(SIGRTMIN + 1, checkHandler);
        return;
    }
    if (sig == SIGRTMAX - 1)
    {
        puts("SIGRTMAX-1 обработчик начал работу!");
        sleep(1);
        signal(SIGRTMAX - 1, checkHandler);
        return;
    }

    if (sig == SIGRTMAX)
    {
        puts("SIGRTMAX обработчик начал работу!");
        sleep(1);
        signal(SIGRTMAX, checkHandler);
        return;
    }
}

int main()
{
    signal(SIGUSR1, checkHandler); // устанавливаем информирующий обработчик
    signal(SIGUSR2, checkHandler);
    signal(SIGBUS, checkHandler);
    signal(SIGIO, checkHandler);

    signal(SIGRTMIN, checkHandler);
    signal(SIGRTMIN + 1, checkHandler);
    signal(SIGRTMAX - 1, checkHandler);
    signal(SIGRTMAX, checkHandler);
    
    int pids;
    if ((pids = fork()) == 0)
    {
        int pid = getppid();
        kill(pid, SIGUSR1);
        kill(pid, SIGUSR1);
        kill(pid, SIGUSR2);
        kill(pid, SIGBUS);
        kill(pid, SIGIO);
        kill(pid, SIGIO);

        kill(pid, SIGRTMIN);
        kill(pid, SIGRTMIN + 1);
        kill(pid, SIGRTMAX - 1);
        kill(pid, SIGRTMAX);
        kill(pid, SIGRTMIN);
        kill(pid, SIGRTMIN);
    }
    sleep(5);
    for (;;)
        pause();
    return 0;
}