#define _GNU_SOURCE
#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>

int main()
{

    union sigval value;
    for (int i = 0; i <= 10; i++)
    {
        value.sival_int = i;
        sigqueue(getppid(), SIGRTMIN, value); // Посылаем надежный сигнал SIGRTMIN с данными
    }

    return 0;
}